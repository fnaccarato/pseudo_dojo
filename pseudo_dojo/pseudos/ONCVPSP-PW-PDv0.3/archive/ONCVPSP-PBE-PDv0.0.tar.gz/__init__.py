# Meta info on the table.

xc_type = "GGA-PBE"

pseudo_type = "norm-conserving"

pseudo_ext = "psp8"

